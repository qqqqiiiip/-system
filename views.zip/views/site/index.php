<?php

/* @var $this yii\web\View */
use yii\widgets\ActiveForm;
use yii\helpers\Html;

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <h1>简介:</h1>
        <p>1.公平</p>
        <p>2.</p>
    <div class="body-content">

        <div class="row">

        </div>

    </div>
</div>
